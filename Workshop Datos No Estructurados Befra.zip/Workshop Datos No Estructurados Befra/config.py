# ============================================================
# config.py — Befra Workshop: Datos No Estructurados
# Edita este archivo para adaptar el demo a tu entorno.
# ============================================================

# --- Unity Catalog -------------------------------------------
CATALOG = "jgworkspaceclassic_catalog"
SCHEMA  = "befra_demo"

# --- Rutas de datos ------------------------------------------
VOLUME_PATH      = f"/Volumes/{CATALOG}/{SCHEMA}/datos_no_estructurados/documentos/"
PARSED_TABLE     = f"{CATALOG}.{SCHEMA}.parsed_befra_docs"
CHUNKS_TABLE     = f"{CATALOG}.{SCHEMA}.befra_chunks"
EMBEDDINGS_TABLE = f"{CATALOG}.{SCHEMA}.befra_embeddings"

# --- Lakebase pgvector ---------------------------------------
PROJECT_ID  = "demo-befra"
BRANCH_ID   = "production"
ENDPOINT_ID = "primary"
DB_NAME     = "databricks_postgres"

# --- Modelos Foundation Model APIs ---------------------------
# Embeddings (1024 dims). Alternativa: databricks-bge-large-en
EMBEDDING_MODEL = "databricks-gte-large-en"
# LLM para generación de respuestas (RAG)
LLM_MODEL       = "databricks-meta-llama-3-3-70b-instruct"

# --- Parámetros del pipeline ---------------------------------
VECTOR_DIM   = 1024   # debe coincidir con el modelo de embeddings
BATCH_SIZE   = 50     # chunks por llamada a la API de embeddings
BATCH_INSERT = 100    # filas por batch al insertar en pgvector
TOP_K        = 5      # resultados en la búsqueda semántica

# ============================================================
# SECCIÓN 2 — Pipeline de Video (transcripción + embeddings)
# ============================================================

# --- Video fuente ----------------------------------------
VIDEO_NAME   = "Lanzamiento Cat 3 - 2026.mp4"
VIDEO_PATH   = f"/Volumes/{CATALOG}/{SCHEMA}/datos_no_estructurados/videos/{VIDEO_NAME}"
AUDIO_TMP    = "/tmp/audio_befra.wav"          # archivo temporal para Whisper

# --- Tabla de destino en Lakebase ------------------------
VIDEO_TABLE_NAME = "video_transcription_embeddings"

# --- Lakebase (comparte PROJECT_ID/BRANCH_ID/ENDPOINT_ID) --
LAKEBASE_ENDPOINT = f"projects/{PROJECT_ID}/branches/{BRANCH_ID}/endpoints/{ENDPOINT_ID}"
LAKEBASE_HOST     = "ep-square-term-d2nsxvwg.database.us-east-1.cloud.databricks.com"
LAKEBASE_DB       = DB_NAME                   # alias para mantener compatibilidad

# --- Whisper (transcripción de audio) --------------------
# Opciones: 'tiny' | 'base' | 'small' | 'medium' | 'large'
# 'small' = buen balance velocidad/precisión en español
# 'medium' o 'large' = mayor precisión (requiere GPU)
WHISPER_MODEL = "small"

# --- Modelo de embeddings multilingüe (768 dims) ----------
# Compatible con español e inglés
VIDEO_EMBEDDING_MODEL = "paraphrase-multilingual-mpnet-base-v2"
VIDEO_EMBEDDING_DIM   = 768
