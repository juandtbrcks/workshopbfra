# Databricks notebook source
# /// script
# [tool.databricks.environment]
# base_environment = "databricks_ai_v5"
# environment_version = "5"
# ///
# DBTITLE 1,Video Transcription & Embeddings — befra_demo
# MAGIC %md
# MAGIC # Video Transcription & Embeddings — befra_demo
# MAGIC
# MAGIC Este notebook implementa el pipeline completo para procesar video con Databricks:
# MAGIC transcripción automática con IA, generación de embeddings por segmento y
# MAGIC búsqueda semántica sobre el contenido del video mediante **pgvector en Lakebase**.
# MAGIC
# MAGIC ## Pipeline
# MAGIC
# MAGIC | Paso | Celda | Descripción |
# MAGIC |------|-------|-------------|
# MAGIC | 1 | `3` | **Extracción de audio** — convierte el video a WAV mono 16 kHz con ffmpeg |
# MAGIC | 2 | `4` | **Transcripción** — Whisper en español, segmentado con timestamps |
# MAGIC | 3 | `5` | **Embeddings** — vectoriza cada segmento con `paraphrase-multilingual-mpnet-base-v2` (768 dims) |
# MAGIC | 4 | `6` | **Lakebase** — crea tabla pgvector e inserta segmentos |
# MAGIC | 5 | `7` | **Búsqueda semántica** — similitud de coseno sobre los embeddings |
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Requisitos previos
# MAGIC
# MAGIC ### Infraestructura
# MAGIC - **Proyecto Lakebase activo** con branch y endpoint en estado `RUNNING`.
# MAGIC - **UC Volume** con el archivo de video accesible desde este workspace.
# MAGIC - **Compute con GPU** (recomendado): Whisper `small`/`medium`/`large` es significativamente
# MAGIC   más rápido en GPU. Este notebook está configurado para usar GPU si está disponible.
# MAGIC   En CPU, el modelo `tiny` o `base` es más práctico.
# MAGIC
# MAGIC ### Permisos
# MAGIC | Permiso | Objeto | Descripción |
# MAGIC |---------|--------|-------------|
# MAGIC | `READ VOLUME` | volume de videos | Leer el archivo MP4 fuente |
# MAGIC | `CONNECT` | Lakebase DB | Conectar a la base de datos |
# MAGIC | `CREATE TABLE` | schema `public` | Crear la tabla de transcripciones |
# MAGIC
# MAGIC ### Librerías (instaladas automáticamente en celda 1)
# MAGIC - `openai-whisper` — transcripción de audio
# MAGIC - `imageio-ffmpeg` — binario ffmpeg auto-descargado (compatible con serverless)
# MAGIC - `sentence-transformers` — embeddings multilingüe
# MAGIC - `psycopg` — conexión a Lakebase/Postgres
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Configuración
# MAGIC
# MAGIC Edita **`config.py`** (en esta misma carpeta) antes de ejecutar:
# MAGIC - `VIDEO_NAME` — nombre del archivo de video
# MAGIC - `CATALOG`, `SCHEMA` — catálogo/schema del UC Volume
# MAGIC - `PROJECT_ID`, `BRANCH_ID`, `ENDPOINT_ID` — coordenadas del proyecto Lakebase
# MAGIC - `WHISPER_MODEL` — `tiny`/`base`/`small`/`medium`/`large` según el compute disponible

# COMMAND ----------

# DBTITLE 1,1 — Instalar dependencias
# imageio-ffmpeg incluye el binario de ffmpeg descargado automáticamente
# → compatible con serverless (no requiere apt-get ni binario del sistema)
%pip install --upgrade \
    "databricks-sdk>=0.118.0" \
    openai-whisper \
    "moviepy>=1.0.3" \
    imageio-ffmpeg \
    "sentence-transformers>=2.2.0" \
    "psycopg[binary]>=3.1.0" \
    -q

# COMMAND ----------

# DBTITLE 1,Restart Python kernel
dbutils.library.restartPython()

# COMMAND ----------

# DBTITLE 1,2 — Configuración
# ── Rutas ──────────────────────────────────────────────────────────────────
# Carga todas las variables del workshop desde config.py
# Edita ese archivo para adaptar el demo a tu entorno.
%run "./config"

# Alias locales para mantener el resto del notebook sin cambios
TABLE_NAME      = VIDEO_TABLE_NAME
EMBEDDING_MODEL = VIDEO_EMBEDDING_MODEL
EMBEDDING_DIM   = VIDEO_EMBEDDING_DIM

# ── Lakebase ────────────────────────────────────────────────────────────────


# ── Modelos ─────────────────────────────────────────────────────────────────
print("Configuración cargada:")
print(f"  Video        : {VIDEO_PATH}")
print(f"  Audio tmp    : {AUDIO_TMP}")
print(f"  Lakebase     : {LAKEBASE_HOST} / {LAKEBASE_DB}")
print(f"  Tabla        : {TABLE_NAME}")
print(f"  Whisper      : {WHISPER_MODEL}")
print(f"  Embed model  : {EMBEDDING_MODEL} ({EMBEDDING_DIM} dims)")

# COMMAND ----------

# DBTITLE 1,3 — Extraer audio del video
import subprocess
import os
import imageio_ffmpeg  # incluye binario de ffmpeg, compatible con serverless

print(f"Extrayendo audio de: {VIDEO_PATH}")
print("Esto puede tardar varios minutos para un archivo de 2 GB...")

# imageio_ffmpeg.get_ffmpeg_exe() devuelve la ruta al binario descargado
# funciona en serverless (no depende de ffmpeg del sistema operativo)
ffmpeg_exe = imageio_ffmpeg.get_ffmpeg_exe()
print(f"ffmpeg en uso: {ffmpeg_exe}")

cmd = [
    ffmpeg_exe, "-y",
    "-i", VIDEO_PATH,
    "-ac", "1",        # mono (Whisper funciona mejor con mono)
    "-ar", "16000",    # 16 kHz requerido por Whisper
    "-vn",             # sin video en el output
    AUDIO_TMP
]

result = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
if result.returncode != 0:
    raise RuntimeError(f"ffmpeg error:\n{result.stderr}")

audio_size_mb = os.path.getsize(AUDIO_TMP) / (1024 ** 2)
print(f"✅ Audio extraído: {AUDIO_TMP} ({audio_size_mb:.1f} MB)")

# COMMAND ----------

# DBTITLE 1,4 — Transcripción con Whisper
import wave
import numpy as np
import whisper
import torch

# Cargar el WAV extraído en celda 3 directamente como array numpy.
# Esto evita que Whisper llame 'ffmpeg' internamente (no está en PATH en serverless).
with wave.open(AUDIO_TMP, 'rb') as wf:
    raw_frames = wf.readframes(wf.getnframes())
    sample_rate = wf.getframerate()

audio_np = np.frombuffer(raw_frames, dtype=np.int16).astype(np.float32) / 32768.0
print(f"Audio cargado: {len(audio_np)/sample_rate:.1f}s a {sample_rate} Hz")

device = "cuda" if torch.cuda.is_available() else "cpu"
print(f"Dispositivo : {device}")
print(f"Cargando modelo Whisper '{WHISPER_MODEL}'...")
whisper_model = whisper.load_model(WHISPER_MODEL, device=device)

print("Transcribiendo audio...")
transcription = whisper_model.transcribe(
    audio_np,
    language="es",
    verbose=False,
    word_timestamps=False,  # poner True si se necesita granularidad por palabra
    fp16=(device == "cuda")  # fp16 solo cuando hay GPU disponible
)

segments = transcription["segments"]
full_text = transcription["text"]

print(f"✅ Transcripción completada")
print(f"   Segmentos detectados : {len(segments)}")
print(f"   Texto total          : {len(full_text)} caracteres")
print(f"\n--- Muestra (primeros 3 segmentos) ---")
for seg in segments[:3]:
    print(f"  [{seg['start']:.1f}s → {seg['end']:.1f}s] {seg['text'].strip()}")

# COMMAND ----------

# DBTITLE 1,4b — Muestra de transcripción
import pandas as pd

# Construir DataFrame con todos los segmentos transcritos
df_transcription = pd.DataFrame([
    {
        "segment_id" : i,
        "start (s)"  : round(seg["start"], 1),
        "end (s)"    : round(seg["end"], 1),
        "duracion (s)": round(seg["end"] - seg["start"], 1),
        "texto"      : seg["text"].strip()
    }
    for i, seg in enumerate(segments)
])

print(f"Total segmentos: {len(df_transcription)}")
print(f"Duración total  : {df_transcription['end (s)'].max():.1f}s "
      f"({df_transcription['end (s)'].max()/60:.1f} min)")
print(f"Texto completo :\n{full_text[:500]}...\n")

display(df_transcription)

# COMMAND ----------

# DBTITLE 1,5 — Generar embeddings por segmento
from sentence_transformers import SentenceTransformer
import numpy as np

print(f"Cargando modelo de embeddings '{EMBEDDING_MODEL}'...")
embed_model = SentenceTransformer(EMBEDDING_MODEL)

# Extraer textos de cada segmento
texts = [seg["text"].strip() for seg in segments if seg["text"].strip()]

print(f"Generando embeddings para {len(texts)} segmentos...")
embeddings = embed_model.encode(
    texts,
    batch_size=32,
    show_progress_bar=True,
    normalize_embeddings=True,   # vectores unitarios; mejora búsqueda coseno
    convert_to_numpy=True
)

print(f"✅ Embeddings generados")
print(f"   Shape  : {embeddings.shape}")
print(f"   Dtype  : {embeddings.dtype}")
print(f"   Norma muestra [0]: {np.linalg.norm(embeddings[0]):.4f}")

# COMMAND ----------

# DBTITLE 1,6 — Configurar tabla en Lakebase (con pgvector)
import psycopg
from databricks.sdk import WorkspaceClient

w = WorkspaceClient()

# Obtener credenciales OAuth de corta duración (validas 1 hora)
username = w.current_user.me().user_name
token    = w.postgres.generate_database_credential(endpoint=LAKEBASE_ENDPOINT).token

def get_connection():
    """Genera una nueva conexión Postgres con token fresco."""
    tok = w.postgres.generate_database_credential(endpoint=LAKEBASE_ENDPOINT).token
    return psycopg.connect(
        host=LAKEBASE_HOST,
        dbname=LAKEBASE_DB,
        user=username,
        password=tok,
        sslmode="require"
    )

conn = get_connection()

with conn.cursor() as cur:
    # Habilitar la extensión pgvector si está disponible
    try:
        cur.execute("CREATE EXTENSION IF NOT EXISTS vector;")
        conn.commit()
        pgvector_available = True
        print("✅ pgvector habilitado")
    except Exception as e:
        conn.rollback()
        pgvector_available = False
        print(f"⚠️  pgvector no disponible, se usará JSONB para los embeddings. ({e})")

    # Crear tabla según disponibilidad de pgvector
    if pgvector_available:
        cur.execute(f"""
            CREATE TABLE IF NOT EXISTS {TABLE_NAME} (
                id             SERIAL PRIMARY KEY,
                video_name     TEXT        NOT NULL,
                segment_id     INTEGER     NOT NULL,
                start_time     FLOAT,
                end_time       FLOAT,
                text           TEXT        NOT NULL,
                embedding      vector({EMBEDDING_DIM}),
                created_at     TIMESTAMP   DEFAULT NOW()
            );
        """)
    else:
        cur.execute(f"""
            CREATE TABLE IF NOT EXISTS {TABLE_NAME} (
                id             SERIAL PRIMARY KEY,
                video_name     TEXT        NOT NULL,
                segment_id     INTEGER     NOT NULL,
                start_time     FLOAT,
                end_time       FLOAT,
                text           TEXT        NOT NULL,
                embedding      JSONB,
                created_at     TIMESTAMP   DEFAULT NOW()
            );
        """)
    conn.commit()
    print(f"✅ Tabla '{TABLE_NAME}' lista en {LAKEBASE_DB}")

# Guardar flag para la celda de inserción
conn.close()

# COMMAND ----------

# DBTITLE 1,7 — Insertar embeddings en Lakebase
import json
from datetime import datetime

conn = get_connection()

# Filtrar segmentos con texto vacío (deben coincidir con los embeddings generados)
valid_segments = [seg for seg in segments if seg["text"].strip()]
assert len(valid_segments) == len(embeddings), (
    f"Desajuste: {len(valid_segments)} segmentos vs {len(embeddings)} embeddings"
)

INSERT_SQL_VECTOR = f"""
    INSERT INTO {TABLE_NAME} (video_name, segment_id, start_time, end_time, text, embedding)
    VALUES (%s, %s, %s, %s, %s, %s::vector)
    ON CONFLICT DO NOTHING;
"""

INSERT_SQL_JSONB = f"""
    INSERT INTO {TABLE_NAME} (video_name, segment_id, start_time, end_time, text, embedding)
    VALUES (%s, %s, %s, %s, %s, %s::jsonb)
    ON CONFLICT DO NOTHING;
"""

inserted = 0
BATCH_SIZE = 50

with conn.cursor() as cur:
    batch_rows = []
    for idx, (seg, emb) in enumerate(zip(valid_segments, embeddings)):
        emb_value = (
            "[" + ",".join(f"{v:.8f}" for v in emb.tolist()) + "]"
            if pgvector_available
            else json.dumps(emb.tolist())
        )
        batch_rows.append((
            VIDEO_NAME,
            idx,
            float(seg["start"]),
            float(seg["end"]),
            seg["text"].strip(),
            emb_value
        ))

        if len(batch_rows) >= BATCH_SIZE:
            sql = INSERT_SQL_VECTOR if pgvector_available else INSERT_SQL_JSONB
            cur.executemany(sql, batch_rows)
            conn.commit()
            inserted += len(batch_rows)
            print(f"  ... insertados {inserted}/{len(valid_segments)} segmentos")
            batch_rows = []

    # Insertar el último batch parcial
    if batch_rows:
        sql = INSERT_SQL_VECTOR if pgvector_available else INSERT_SQL_JSONB
        cur.executemany(sql, batch_rows)
        conn.commit()
        inserted += len(batch_rows)

conn.close()
print(f"✅ Total insertado: {inserted} segmentos en '{TABLE_NAME}'")

# COMMAND ----------

# DBTITLE 1,8 — Verificar y buscar por similitud (búsqueda vectorial)
# ───────────────────────────────────────────────────────────────────
# Verifica filas insertadas y hace una búsqueda semántica de ejemplo
# ───────────────────────────────────────────────────────────────────
conn = get_connection()

# 1. Conteo total
with conn.cursor() as cur:
    cur.execute(f"SELECT COUNT(*), MIN(start_time), MAX(end_time) FROM {TABLE_NAME} WHERE video_name = %s", (VIDEO_NAME,))
    count, min_t, max_t = cur.fetchone()
    print(f"Filas en Lakebase: {count}")
    print(f"Duración cubierta : {min_t:.1f}s → {max_t:.1f}s ({max_t/60:.1f} min)")

# 2. Búsqueda por similitud coseno (solo con pgvector)
if pgvector_available:
    QUERY_TEXT = "características del producto"   # <-- cambia según lo que busques
    print(f"\nBúsqueda semántica: '{QUERY_TEXT}'")
    query_emb = embed_model.encode([QUERY_TEXT], normalize_embeddings=True)[0]
    query_vec = "[" + ",".join(f"{v:.8f}" for v in query_emb.tolist()) + "]"

    with conn.cursor() as cur:
        cur.execute(f"""
            SELECT segment_id, start_time, end_time, text,
                   1 - (embedding <=> %s::vector) AS similarity
            FROM {TABLE_NAME}
            WHERE video_name = %s
            ORDER BY embedding <=> %s::vector
            LIMIT 5;
        """, (query_vec, VIDEO_NAME, query_vec))
        rows = cur.fetchall()

    print("\nTop 5 segmentos más similares:")
    for seg_id, start, end, text, sim in rows:
        print(f"  [{start:.1f}s→{end:.1f}s] sim={sim:.3f}  {text[:80]}")
else:
    print("\nBúsqueda vectorial disponible solo con pgvector.")
    print("Consulta los segmentos con: SELECT * FROM video_transcription_embeddings LIMIT 10;")

conn.close()

# COMMAND ----------

# DBTITLE 1,9 — Opcional: crear índice IVFFlat para búsqueda rápida
# ❌ Solo ejecutar tras insertar TODOS los segmentos.
# El índice IVFFlat mejora la velocidad de búsqueda ANN en tablas grandes.
# lists = ceil(sqrt(n_filas)); ajustar según el volumen de datos.

if pgvector_available:
    conn = get_connection()
    with conn.cursor() as cur:
        cur.execute(f"""
            CREATE INDEX IF NOT EXISTS idx_{TABLE_NAME}_embedding
            ON {TABLE_NAME}
            USING ivfflat (embedding vector_cosine_ops)
            WITH (lists = 20);
        """)
        conn.commit()
    conn.close()
    print("✅ Índice IVFFlat creado sobre columna 'embedding'")
else:
    print("pgvector no disponible, no se puede crear índice vectorial.")