# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# DBTITLE 1,Intro
# MAGIC %md
# MAGIC # Befra — Workshop: Datos No Estructurados
# MAGIC
# MAGIC Este notebook demuestra el pipeline completo para procesar catálogos PDF con Databricks:
# MAGIC extracción de contenido e imágenes con IA, generación de embeddings y búsqueda semántica
# MAGIC mediante **pgvector en Lakebase**.
# MAGIC
# MAGIC ## Pipeline
# MAGIC
# MAGIC | Paso | Celda | Descripción |
# MAGIC |------|-------|-------------|
# MAGIC | 1 | `2` | **Extracción** — OCR + descripción de imágenes con `ai_parse_document()` |
# MAGIC | 2 | `4` | **Chunking** — Fragmentar elementos; traducir descripciones de figuras al español con `ai_translate()` |
# MAGIC | 3 | `5` | **Embeddings** — Vectorizar con `databricks-gte-large-en` (1 024 dims) |
# MAGIC | 4 | `6–7` | **Lakebase** — Crear tabla pgvector e insertar vectores |
# MAGIC | 5 | `8` | **Búsqueda semántica** — Similitud de coseno sobre los embeddings |
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Requisitos previos
# MAGIC
# MAGIC ### Infraestructura
# MAGIC - **Proyecto Lakebase activo** con un branch (`production`) y un endpoint (`primary`) en estado `RUNNING`.
# MAGIC   Verifica en *Data* → *Lakebase* que el endpoint esté disponible antes de ejecutar los pasos 4–5.
# MAGIC - **UC Volume** con los PDFs fuente accesible desde este workspace.
# MAGIC - **Compute**: Serverless SQL o All-Purpose Cluster con acceso a Foundation Model APIs
# MAGIC   (requerido por `ai_parse_document()` y `ai_translate()`).
# MAGIC
# MAGIC ### Permisos de Unity Catalog
# MAGIC | Permiso | Objeto |
# MAGIC |---------|--------|
# MAGIC | `USE CATALOG` | catalog |
# MAGIC | `USE SCHEMA` | schema |
# MAGIC | `CREATE TABLE` | schema |
# MAGIC | `READ VOLUME` | volume con los PDFs |
# MAGIC
# MAGIC ### Permisos de Lakebase
# MAGIC | Permiso | Objeto |
# MAGIC |---------|--------|
# MAGIC | `CAN USE` | Proyecto Lakebase (vía UI: *Data → Lakebase → [proyecto] → Permissions*) |
# MAGIC | `CONNECT` | Database `databricks_postgres` |
# MAGIC | `USAGE`, `CREATE` | Schema `public` |
# MAGIC | `EXECUTE` | Functions en schema `public` (operador `<=>` de pgvector) |
# MAGIC
# MAGIC ### Modelos Foundation (PAYG o Provisioned)
# MAGIC - `databricks-gte-large-en` — embeddings (1 024 dims)
# MAGIC - `ai_translate()` — traducción de descripciones de imágenes al español
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Configuración
# MAGIC
# MAGIC Antes de ejecutar, edita **`config.py`** (en esta misma carpeta) con los valores de tu entorno:
# MAGIC - `CATALOG`, `SCHEMA` — destino de las tablas Delta
# MAGIC - `VOLUME_PATH` — ruta al UC Volume con los PDFs
# MAGIC - `PROJECT_ID`, `BRANCH_ID`, `ENDPOINT_ID` — coordenadas del proyecto Lakebase
# MAGIC
# MAGIC La celda `Configuración` carga estas variables automáticamente con `%run "./config"`.

# COMMAND ----------

# DBTITLE 1,1. Instalar dependencias
# Instalar dependencias necesarias para Lakebase + pgvector
%pip install -q --upgrade \
    "databricks-sdk>=0.118.0" \
    "psycopg[binary]>=3.1.0" \
    "pgvector>=0.3.0"

# COMMAND ----------

# DBTITLE 1,Restart Python
dbutils.library.restartPython()

# COMMAND ----------

# DBTITLE 1,Configuración — cargar config.py
# Carga todas las variables del workshop desde config.py
# Edita ese archivo para adaptar el demo a tu entorno.
%run "./config"

print("Configuración cargada:")
print(f"  Catalog / Schema : {CATALOG}.{SCHEMA}")
print(f"  Volume path      : {VOLUME_PATH}")
print(f"  Lakebase project : {PROJECT_ID} / {BRANCH_ID}")
print(f"  Embedding model  : {EMBEDDING_MODEL}")
print(f"  LLM model        : {LLM_MODEL}")
print(f"  Vector dim       : {VECTOR_DIM} | Batch: {BATCH_SIZE} | Top-K: {TOP_K}")

# COMMAND ----------

# DBTITLE 1,Step 1 header
# MAGIC %md
# MAGIC ## Paso 1 — Extraer contenido de los PDFs
# MAGIC
# MAGIC Usamos `ai_parse_document()` v2 con `descriptionElementTypes='*'` para:
# MAGIC - Extraer texto (OCR de páginas escaneadas)
# MAGIC - Generar descripciones de imágenes/figuras con IA
# MAGIC - Parsear tablas como HTML estructurado
# MAGIC
# MAGIC El resultado se persiste en Delta como `parsed_befra_docs` para no reprocesar.

# COMMAND ----------

# DBTITLE 1,2. Parsear documentos e imágenes con ai_parse_document
# Soporta PDF, JPG, JPEG, PNG, TIFF, DOCX, PPTX
# regexp_extract con $ captura el nombre del archivo (ultimo segmento del path)
spark.sql(
    "CREATE OR REPLACE TABLE " + PARSED_TABLE + " AS "
    "SELECT "
    "  path, "
    "  regexp_extract(path, '([^/]+)$', 1) AS filename, "
    "  ai_parse_document(content, map('version', '2.0', 'descriptionElementTypes', '*')) AS parsed "
    "FROM READ_FILES('" + VOLUME_PATH + "', format => 'binaryFile')"
)

print("Documentos procesados:")
spark.sql("SELECT filename, size(cast(parsed:document:elements AS ARRAY<VARIANT>)) AS total_elements FROM " + PARSED_TABLE).show()

# COMMAND ----------

# DBTITLE 1,2b. Muestra del contenido extraído por ai_parse_document
df_muestra = spark.sql(f"""
  SELECT
    regexp_extract(path, '([^/]+\\.[^/]+)$', 1)   AS filename,
    try_cast(element:page        AS INT)            AS pagina,
    try_cast(element:type        AS STRING)         AS tipo,
    LEFT(
      COALESCE(
        try_cast(element:content     AS STRING),
        try_cast(element:description AS STRING)
      ), 300
    )                                               AS contenido_preview
  FROM {PARSED_TABLE}
  LATERAL VIEW EXPLODE(
    from_json(to_json(parsed:document:elements), 'ARRAY<VARIANT>')
  ) AS element
  WHERE COALESCE(
    try_cast(element:content AS STRING),
    try_cast(element:description AS STRING)
  ) IS NOT NULL
  ORDER BY filename, pagina, tipo
  LIMIT 50
""")

print(f"Muestra de elementos extraídos (primeros 50):")
display(df_muestra)

# COMMAND ----------

# DBTITLE 1,3. Verificar errores de parseo
# Verificar que no hay errores de parseo
errors = spark.sql(f"""
  SELECT filename, parsed:error_status AS error
  FROM {PARSED_TABLE}
  WHERE try_cast(parsed:error_status AS STRING) IS NOT NULL
""")
print(f"Documentos con error: {errors.count()}")

# Vista rápida de los tipos de elementos encontrados
spark.sql(f"""
  SELECT
    filename,
    element['type'] AS tipo,
    COUNT(*) AS cantidad
  FROM {PARSED_TABLE}
  LATERAL VIEW EXPLODE(from_json(to_json(parsed:document:elements), 'ARRAY<STRUCT<type:STRING>>')) AS element
  GROUP BY 1, 2
  ORDER BY 1, 3 DESC
""").show(40)

# COMMAND ----------

# DBTITLE 1,Análisis de elementos por documento (tipo, tamaño, posición)
# ============================================================
# Análisis de imágenes (figures) por documento
# Posición, tamaño y descripción en español ya persistidos
# en {CHUNKS_TABLE} desde el Paso 2.
# ============================================================
df_figures = spark.sql(f"""
  SELECT
    filename,
    page_number                                              AS pagina,
    x1, y1, x2, y2,
    ancho_px, alto_px,
    ROUND(ancho_px * alto_px / 1e6, 3)                      AS area_mpx,
    confianza,
    descripcion_ia_es
  FROM {CHUNKS_TABLE}
  WHERE element_type = 'figure'
    AND x1 IS NOT NULL
""")

# Resumen por documento
df_figures.createOrReplaceTempView("_figures")
print("RESUMEN DE IMÁGENES POR DOCUMENTO")
display(spark.sql("""
  SELECT
    filename,
    COUNT(*)                        AS total_imagenes,
    COUNT(DISTINCT pagina)          AS paginas_con_imagenes,
    ROUND(AVG(ancho_px), 0)         AS ancho_promedio_px,
    ROUND(AVG(alto_px),  0)         AS alto_promedio_px,
    ROUND(AVG(area_mpx), 3)         AS area_promedio_mpx,
    ROUND(MIN(confianza), 3)        AS confianza_min,
    ROUND(AVG(confianza), 3)        AS confianza_promedio
  FROM _figures
  GROUP BY filename
  ORDER BY filename
"""))

# Detalle completo con descripción en español
print("DETALLE DE IMÁGENES — POSICIÓN, TAMAÑO Y DESCRIPCIÓN IA")
display(
  spark.sql("""
    SELECT filename, pagina, x1, y1, ancho_px, alto_px, area_mpx, confianza,
           LEFT(descripcion_ia_es, 200) AS descripcion_ia_es
    FROM _figures
    ORDER BY filename, pagina, y1
  """)
)

# COMMAND ----------

# DBTITLE 1,Step 2 header
# MAGIC %md
# MAGIC ## Paso 2 — Chunking semántico
# MAGIC
# MAGIC Extraemos cada elemento del documento (texto, títulos, tablas, descripciones de imágenes) como un chunk individual.
# MAGIC Cada chunk incluye contexto: nombre del documento y número de página.

# COMMAND ----------

# DBTITLE 1,4. Extraer y preparar chunks
# Extraer cada elemento como un chunk independiente con su contexto
spark.sql(f"""
  CREATE OR REPLACE TABLE {CHUNKS_TABLE} AS
  WITH exploded AS (
    SELECT
      filename,
      path,
      posexplode(from_json(to_json(parsed:document:elements), 'ARRAY<VARIANT>')) AS (pos, element)
    FROM {PARSED_TABLE}
    WHERE try_cast(parsed:error_status AS STRING) IS NULL
  )
  SELECT
    filename,
    path,
    pos                                                      AS element_index,
    try_cast(element:type        AS STRING)                  AS element_type,
    try_cast(element:page        AS INT)                     AS page_number,
    -- Posición y tamaño (bbox) — persistidos para análisis de imágenes
    try_cast(element:bbox[0]:coord[0] AS INT)                AS x1,
    try_cast(element:bbox[0]:coord[1] AS INT)                AS y1,
    try_cast(element:bbox[0]:coord[2] AS INT)                AS x2,
    try_cast(element:bbox[0]:coord[3] AS INT)                AS y2,
    try_cast(element:bbox[0]:coord[2] AS INT)
      - try_cast(element:bbox[0]:coord[0] AS INT)            AS ancho_px,
    try_cast(element:bbox[0]:coord[3] AS INT)
      - try_cast(element:bbox[0]:coord[1] AS INT)            AS alto_px,
    ROUND(try_cast(element:confidence AS DOUBLE), 3)         AS confianza,
    COALESCE(
      try_cast(element:content     AS STRING),   -- texto, tablas, titulos
      try_cast(element:description AS STRING)    -- descripcion de imagenes/figuras
    )                                                        AS chunk_text,
    CONCAT(
      'Documento: ', filename,
      ' | Pagina: ', COALESCE(CAST(try_cast(element:page AS INT) AS STRING), '?'),
      ' | Tipo: ',   COALESCE(try_cast(element:type AS STRING), 'unknown'),
      '\n\n',
      COALESCE(
        try_cast(element:content AS STRING),
        try_cast(element:description AS STRING),
        ''
      )
    )                                                        AS chunk_text_with_context,
    -- Descripción en español (solo figuras) — traducida una vez en ingesta
    CASE
      WHEN try_cast(element:type AS STRING) = 'figure'
        AND try_cast(element:description AS STRING) IS NOT NULL
      THEN ai_translate(try_cast(element:description AS STRING), 'Spanish')
      ELSE NULL
    END                                                      AS descripcion_ia_es
  FROM exploded
  WHERE COALESCE(
    try_cast(element:content AS STRING),
    try_cast(element:description AS STRING)
  ) IS NOT NULL
  AND length(COALESCE(
    try_cast(element:content AS STRING),
    try_cast(element:description AS STRING)
  )) > 10
""")

count = spark.sql(f"SELECT COUNT(*) as n FROM {CHUNKS_TABLE}").collect()[0]['n']
print(f"Total de chunks generados: {count:,}")
spark.sql(f"SELECT filename, element_type, COUNT(*) as n FROM {CHUNKS_TABLE} GROUP BY 1,2 ORDER BY 1,3 DESC").show(30)

# COMMAND ----------

# DBTITLE 1,Step 3 header
# MAGIC %md
# MAGIC ## Paso 3 — Generar embeddings
# MAGIC
# MAGIC Usamos `databricks-gte-large-en` (1024 dimensiones) disponible vía Foundation Model APIs.
# MAGIC Los embeddings se generan en lotes para eficiencia y se guardan en Delta.

# COMMAND ----------

# DBTITLE 1,5. Generar embeddings con Databricks Foundation Models
from mlflow.deployments import get_deploy_client
import pandas as pd
from pyspark.sql.functions import udf, col
from pyspark.sql.types import ArrayType, FloatType
import time

deploy_client = get_deploy_client("databricks")

def get_embeddings_batch(texts: list[str]) -> list[list[float]]:
    """Llama a Foundation Models API en lotes."""
    response = deploy_client.predict(
        endpoint=EMBEDDING_MODEL,
        inputs={"input": texts}
    )
    return [item["embedding"] for item in response["data"]]

# Cargar chunks en pandas para procesar en lotes
chunks_df = spark.sql(f"""
  SELECT
    monotonically_increasing_id() AS chunk_id,
    filename, path, element_index, element_type, page_number,
    chunk_text, chunk_text_with_context, descripcion_ia_es
  FROM {CHUNKS_TABLE}
""").toPandas()

print(f"Generando embeddings para {len(chunks_df):,} chunks...")

# Generar embeddings en lotes
all_embeddings = []
texts = chunks_df["chunk_text_with_context"].tolist()

for i in range(0, len(texts), BATCH_SIZE):
    batch = texts[i : i + BATCH_SIZE]
    embeddings = get_embeddings_batch(batch)
    all_embeddings.extend(embeddings)
    print(f"  Procesados {min(i + BATCH_SIZE, len(texts)):,} / {len(texts):,} chunks", end="\r")
    time.sleep(0.2)  # respetar rate limits

print(f"\nEmbeddings generados: {len(all_embeddings):,} | Dimensiones: {len(all_embeddings[0])}")

# Agregar embeddings al dataframe
chunks_df["embedding"] = all_embeddings

# Guardar en Delta (como JSON string para compatibilidad)
result_spark = spark.createDataFrame(chunks_df)
result_spark.write.mode("overwrite").saveAsTable(EMBEDDINGS_TABLE)
print(f"Tabla {EMBEDDINGS_TABLE} guardada correctamente.")

# COMMAND ----------



# COMMAND ----------

# DBTITLE 1,Step 4 header
# MAGIC %md
# MAGIC ## Paso 4 — Setup pgvector en Lakebase `demo-befra`
# MAGIC
# MAGIC Conectamos al proyecto Lakebase, habilitamos la extensión `pgvector` y creamos la tabla
# MAGIC `betterware_embeddings` con una columna de tipo `vector(1024)`.

# COMMAND ----------

# DBTITLE 1,6. Conectar a Lakebase y crear tabla pgvector
import psycopg
from databricks.sdk import WorkspaceClient

w = WorkspaceClient()
endpoint_name = f"projects/{PROJECT_ID}/branches/{BRANCH_ID}/endpoints/{ENDPOINT_ID}"
endpoint = w.postgres.get_endpoint(name=endpoint_name)
host     = endpoint.status.hosts.host
username = w.current_user.me().user_name
token    = w.postgres.generate_database_credential(endpoint=endpoint_name).token

print(f"Conectando a: {host}")
print(f"Usuario: {username}")

DDL = f"""
-- Habilitar pgvector
CREATE EXTENSION IF NOT EXISTS vector;

-- Tabla de embeddings (recrear para incluir columna path)
DROP TABLE IF EXISTS public.betterware_embeddings;
CREATE TABLE public.betterware_embeddings (
    id              SERIAL PRIMARY KEY,
    chunk_id        BIGINT,
    filename        TEXT,
    path            TEXT,
    page_number     INT,
    element_type    TEXT,
    chunk_text      TEXT,
    embedding       vector({VECTOR_DIM})
);

-- Índice HNSW para búsqueda por similitud de coseno
CREATE INDEX IF NOT EXISTS idx_betterware_hnsw
  ON public.betterware_embeddings
  USING hnsw (embedding vector_cosine_ops)
  WITH (m = 16, ef_construction = 64);
"""

with psycopg.connect(
    host=host, dbname=DB_NAME,
    user=username, password=token, sslmode="require"
) as conn:
    conn.autocommit = True
    with conn.cursor() as cur:
        for stmt in DDL.strip().split(";"):
            s = stmt.strip()
            if s:
                cur.execute(s)
        cur.execute("SELECT extversion FROM pg_extension WHERE extname = 'vector'")
        version = cur.fetchone()
        print(f"\npgvector version: {version[0] if version else 'instalada'}")
        cur.execute("SELECT COUNT(*) FROM public.betterware_embeddings")
        print(f"Registros actuales en la tabla: {cur.fetchone()[0]:,}")

print("\nTabla betterware_embeddings lista.")

# COMMAND ----------

# DBTITLE 1,7. Insertar embeddings en pgvector
import psycopg
import pandas as pd
import json
from databricks.sdk import WorkspaceClient
from pyspark.sql import functions as F

w = WorkspaceClient()
endpoint_name = f"projects/{PROJECT_ID}/branches/{BRANCH_ID}/endpoints/{ENDPOINT_ID}"
endpoint = w.postgres.get_endpoint(name=endpoint_name)
host     = endpoint.status.hosts.host
username = w.current_user.me().user_name
token    = w.postgres.generate_database_credential(endpoint=endpoint_name).token

# Cargar embeddings desde Delta
df = spark.table(EMBEDDINGS_TABLE).select(
    "chunk_id", "filename", "path", "page_number", "element_type",
    "chunk_text", "embedding"
).toPandas()

print(f"Insertando {len(df):,} registros en Lakebase...")

INSERT_SQL = """
  INSERT INTO public.betterware_embeddings
    (chunk_id, filename, path, page_number, element_type, chunk_text, embedding)
  VALUES (%s, %s, %s, %s, %s, %s, %s)
  ON CONFLICT DO NOTHING
"""

with psycopg.connect(
    host=host, dbname=DB_NAME,
    user=username, password=token, sslmode="require"
) as conn:
    with conn.cursor() as cur:
        # Limpiar registros anteriores para idempotencia
        cur.execute("TRUNCATE TABLE public.betterware_embeddings RESTART IDENTITY")
        conn.commit()

        rows_inserted = 0
        for i in range(0, len(df), BATCH_INSERT):
            batch = df.iloc[i : i + BATCH_INSERT]
            records = [
                (
                    int(row.chunk_id) if pd.notna(row.chunk_id) else None,
                    row.filename,
                    row.path,
                    int(row.page_number) if pd.notna(row.page_number) else None,
                    row.element_type,
                    row.chunk_text,
                    "[" + ",".join(str(float(x)) for x in row.embedding) + "]"  # pgvector: '[0.1,-0.2,...]'
                )
                for _, row in batch.iterrows()
            ]
            cur.executemany(INSERT_SQL, records)
            rows_inserted += len(records)
            print(f"  Insertados {rows_inserted:,} / {len(df):,}", end="\r")
        conn.commit()

        cur.execute("SELECT COUNT(*) FROM public.betterware_embeddings")
        total = cur.fetchone()[0]
        print(f"\n\nTotal en betterware_embeddings: {total:,} vectores")

# COMMAND ----------

# DBTITLE 1,Step 5 header
# MAGIC %md
# MAGIC ## Paso 5 — Búsqueda semántica con pgvector
# MAGIC
# MAGIC Consulta de similitud por coseno: dada una pregunta en lenguaje natural, obtenemos
# MAGIC el embedding de la pregunta y buscamos los chunks más cercanos en el espacio vectorial.

# COMMAND ----------

# DBTITLE 1,8. Busqueda semantica - ejemplo
import psycopg
from mlflow.deployments import get_deploy_client
from databricks.sdk import WorkspaceClient

# --- Modifica la pregunta aquí ---
QUERY = "Mesa de comedor para sala"
# ----------------------------------

w = WorkspaceClient()
endpoint_name = f"projects/{PROJECT_ID}/branches/{BRANCH_ID}/endpoints/{ENDPOINT_ID}"
endpoint = w.postgres.get_endpoint(name=endpoint_name)
host     = endpoint.status.hosts.host
username = w.current_user.me().user_name
token    = w.postgres.generate_database_credential(endpoint=endpoint_name).token
deploy_client = get_deploy_client("databricks")

# Generar embedding de la consulta
print(f'Buscando: "{QUERY}"...')
query_response = deploy_client.predict(
    endpoint=EMBEDDING_MODEL,
    inputs={"input": [QUERY]}
)
query_embedding = query_response["data"][0]["embedding"]
query_vector_str = "[" + ",".join(str(float(x)) for x in query_embedding) + "]"

# Busqueda por similitud de coseno
SEARCH_SQL = f"""
  SELECT
    id,
    filename,
    page_number,
    element_type,
    LEFT(chunk_text, 300) AS chunk_preview,
    1 - (embedding <=> '{query_vector_str}'::vector) AS cosine_similarity
  FROM public.betterware_embeddings
  ORDER BY embedding <=> '{query_vector_str}'::vector
  LIMIT {TOP_K};
"""

with psycopg.connect(
    host=host, dbname=DB_NAME,
    user=username, password=token, sslmode="require"
) as conn:
    with conn.cursor() as cur:
        cur.execute(SEARCH_SQL)
        results = cur.fetchall()

print(f"\nTop {TOP_K} resultados más similares:\n{'='*70}")
for row in results:
    id_, filename, page, etype, preview, score = row
    print(f"[Score: {score:.4f}] {filename} | Pág. {page} | Tipo: {etype}")
    print(f"  {preview[:200]}")
    print("-" * 70)

# COMMAND ----------

# DBTITLE 1,9. Stats finales del pipeline
import psycopg
from databricks.sdk import WorkspaceClient

w = WorkspaceClient()
endpoint_name = f"projects/{PROJECT_ID}/branches/{BRANCH_ID}/endpoints/{ENDPOINT_ID}"
endpoint = w.postgres.get_endpoint(name=endpoint_name)
host     = endpoint.status.hosts.host
username = w.current_user.me().user_name
token    = w.postgres.generate_database_credential(endpoint=endpoint_name).token

with psycopg.connect(
    host=host, dbname=DB_NAME,
    user=username, password=token, sslmode="require"
) as conn:
    with conn.cursor() as cur:
        # Stats por documento
        cur.execute("""
          SELECT
            filename,
            COUNT(*) AS total_chunks,
            COUNT(DISTINCT page_number) AS paginas,
            COUNT(CASE WHEN element_type = 'figure' THEN 1 END) AS imagenes_descritas,
            COUNT(CASE WHEN element_type = 'table'  THEN 1 END) AS tablas
          FROM public.betterware_embeddings
          GROUP BY filename
          ORDER BY filename
        """)
        print("Resumen del pipeline:\n" + "="*65)
        print(f"{'Archivo':<30} {'Chunks':>8} {'Pag':>5} {'Imgs':>6} {'Tablas':>7}")
        print("-" * 65)
        for row in cur.fetchall():
            filename, chunks, pages, imgs, tables = row
            print(f"{filename:<30} {chunks:>8,} {pages:>5} {imgs:>6} {tables:>7}")
        print("\nDatos almacenados con éxito en pgvector (Lakebase demo-befra)")